/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.multipleattributes;

/**
 *
 * @author Lenovo-User
 */
public class Main {
 String fname = "Monde";
    String lname = "Zondi";
    int age = 23;
    
    public static void main(String[] args) {
        Main myObj = new Main();
        System.out.println("Name: " + myObj .fname + " " + myObj. lname);
        System.out.println("Age: " + myObj.age);   
    }
}