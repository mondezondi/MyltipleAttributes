/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.multipleattributes;

/**
 *
 * @author Lenovo-User
 */
public class App {
    String fname = "Monde";
    String lname = "Zondi";
    int age = 23;
    
    public static void main(String[] args) {
        Main myObj = new Main();
        System.out.println("Name: " + myObj .fname + " " + myObj. lname);
        System.out.println("Age: " + myObj.age);
    }
}
